// Import necessary modules
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

// Create Express app
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Set up body-parser middleware
app.use(bodyParser.urlencoded({ extended: true }));

// Define routes
app.get('/', (req, res) => {
    res.render('home');
});

app.get('/login', (req, res) => {
    res.render('login');
});


app.post('/login', (req, res) => {
    // Handle login logic here
    // For simplicity, let's assume login is successful
    res.redirect('/');
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
